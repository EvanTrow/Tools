import express from 'express';
import { createLogger } from '@root/helpers';

// logging
const console = createLogger('Hello');

const router = express.Router();

router.get('/', async (req, res) => {
	console.log('Hello World!');
	res.json({ message: 'Hello World!' });
});

export const service = {
	path: '/api/hello',
	router: router,
};
