import { Container, Grid2 } from '@mui/material';
import { WavingHand } from '@mui/icons-material';
import ToolTitle from '../../components/ToolTitle';
import { Tool } from '../AllTools';

const tool: Tool = {
	title: 'Hello',
	pageTitle: 'Template Tool',
	description: 'Example of an extension tool',
	path: '/hello/hello',
	page: Hello,
	icon: <WavingHand />,
};
export default tool;

function Hello() {
	return (
		<Container maxWidth='md'>
			<ToolTitle tool={tool} />
			<Grid2 container spacing={2} direction={{ xs: 'column', md: 'row' }}>
				<Grid2 size={{ xs: 12 }}>Hello World!</Grid2>
			</Grid2>
		</Container>
	);
}
